@echo off
setlocal DisableDelayedExpansion
"%~dp0node.exe" "%~dp0host.mjs" %*
exit /b %errorlevel%
